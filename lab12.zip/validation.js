function validateForm() {
	var mess = document.getElementById("message").value;
	var sid = document.getElementById("studentid").value;
	var errMsg = "";
	var result = true;

	if (mess == "") {
		errMsg += "Message cannot be empty.\n"
	}
	if (sid == "") {
		errMsg += "Student ID cannot be empty.\n"
	}
	if (sid[0] !== "s") {
		errMsg += "Student ID must start with s.\n";
    }
	if (errMsg != "") {
		alert (errMsg);
		result = false;
	} 
	return result;
}

/* link HTML elements to corresponding event function */
function init () {
	/* link the variables to the HTML elements */
	var msgForm = 	document.getElementById("msgform");
	msgForm.onsubmit = validateForm;
}

/* execute the initialisation function once the window*/
window.onload = init;
